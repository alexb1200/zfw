def inDict(dict,key):
    try:dict[key]
    except:return False
    return True

testStr=b"itty bitty spider went down the water spout. itty bitty spider went down the water spout. itty bitty spider went down the water spout."
dict ={}


for i in range(0,255):
    dict[chr(i)]=i
#print(testStr[0])
#print(dict["i"])



code=255
nuText=[]
string=""
for b in range(len(testStr)-1):
    string += chr(testStr[b])
    next = chr(testStr[b + 1])

    if not(inDict(dict,string+next)):
        #print(string,"::::",dict[string]) #uncomment to see what string is assaoited with what code
        nuText.append(dict[string])
        code+=1
        dict[string+next]=code
        string=""
nuText.append(dict[next]) #grab the last char, the for loop doesnt pick it up because next looks ahead




print("Compressed Size:",len(nuText))
print("Original Size",len(testStr))

print("reduced by: ",(1- len(nuText)/len(testStr))*100,"%")

#remaking the dictionary
dict ={}
for i in range(0,255):
    dict[i]=chr(i)

#setup for decompression
recoveredText=chr(nuText[0]) #grab first char
char=""
key=256
NextCode=nuText[0]
PrevCode=nuText[0]

for b in range(len(nuText)-1):


    NextCode = nuText[b + 1]
    if(inDict(dict,NextCode)):
        string = dict[NextCode]

    else:
        string = dict[nuText[b]]
        string += char
    recoveredText += string
    #print(string, ":::",NextCode)

    #rebuilding the dictionary
    char=string[0]
    dict[key]=dict[PrevCode]+char
    key+=1
    #print(PrevCode,":::::",NextCode)
    PrevCode=NextCode
print("\nrecovered text:")
print(recoveredText)










